import Controller.Program;

public class App {
    public static void main(String[] args) throws Exception {
        new Program().run();
    }
}
